<ins><b>Scope:</b></ins>

The scope of the project is to develop a web application for the people living in a society so as to ease
the process of managing the various activities and events of a society. Society Management System automates
certain attributes that occur within the society and makes it easy for the members and administrators of
the society to view, store and manage the different activities.

<ins><b>Features:</b></ins>

1. Login admin
2. Login user
3. Login Security
4. Forgot password 

-------------- ADMIN -------------------

1. Flats
2. Flat Area
3. Bills
4. Complaints
5. Visitors
6. Security
7. Shoutbox
8. Dashboard
9. Allotment
10. Profile

-------------- USER -------------------

1. Bills
2. Complaints
3. Visitors
4. Security
5. Shoutbox
6. Dashboard
7. Profile

--------------SECURITY-------------------

1. Visitor
2. Profile
3. Settings
